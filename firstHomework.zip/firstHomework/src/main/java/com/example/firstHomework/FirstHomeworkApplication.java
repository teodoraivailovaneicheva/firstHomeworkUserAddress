package com.example.firstHomework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstHomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstHomeworkApplication.class, args);
	}

}
